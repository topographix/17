#!/bin/bash
# RedVelvet APK Build Script
# Production-ready Android APK with version control

# Get current version
VERSION=$(node -p "require('./version.json').version")
echo "🚀 Building RedVelvet Android APK v$VERSION..."

# Sync web assets to Android
npx cap sync android

# Update Android app version
cd android
echo "📋 Setting APK version to v$VERSION"
sed -i "s/versionName \".*\"/versionName \"$VERSION\"/" app/build.gradle

# Build APK
echo "📱 Generating APK with all mobile fixes..."
./gradlew assembleDebug

# Rename APK with version
if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    mv app/build/outputs/apk/debug/app-debug.apk app/build/outputs/apk/debug/RedVelvet-v$VERSION.apk
    echo "✅ APK Generated: android/app/build/outputs/apk/debug/RedVelvet-v$VERSION.apk"
else
    echo "❌ APK build failed"
    exit 1
fi

echo "🔧 Includes: AI chat, diamond system, fixed back button, keyboard handling"